public class HelloGroland {
    public static void main(String[] args) {
        System.out.println("Hello Groland");
    }
}
