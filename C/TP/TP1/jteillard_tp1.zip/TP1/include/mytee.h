int mytee(char* fname);
