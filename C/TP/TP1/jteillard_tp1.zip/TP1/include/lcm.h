/**
 * The lowest common multiple of two numbers.
 * 
 * @param a the first number
 * @param b the second number
 * @return the lowest common multiple
 */
int lcm(int a, int b);