/**
 * Mirrors a given string.
 * 
 * @return void
 * @param string ; the string to mirror
 */
void mirror_string(char* string);